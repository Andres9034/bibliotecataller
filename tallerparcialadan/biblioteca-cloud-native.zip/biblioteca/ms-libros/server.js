// Microservicio A - Libros (Node.js + Express + PostgreSQL)
// 12 factores: config por variables de entorno, sin estado, logs a stdout, puerto por PORT.
const express = require('express');
const { Pool } = require('pg');

const PORT = process.env.PORT || 8001;
const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 5432),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

const log = (msg, extra = {}) =>
  console.log(JSON.stringify({ ts: new Date().toISOString(), service: 'ms-libros', msg, ...extra }));

async function initDb(retries = 20) {
  for (let i = 1; i <= retries; i++) {
    try {
      await pool.query(`CREATE TABLE IF NOT EXISTS libros (
        id SERIAL PRIMARY KEY,
        titulo VARCHAR(200) NOT NULL,
        autor VARCHAR(150) NOT NULL,
        creado_por VARCHAR(128),
        creado_en TIMESTAMP DEFAULT NOW()
      )`);
      log('Base de datos lista');
      return;
    } catch (e) {
      log('BD no disponible, reintentando', { intento: i, error: e.message });
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
  throw new Error('No se pudo conectar a PostgreSQL');
}

const app = express();
app.use(express.json());
app.use((req, _res, next) => { log('request', { method: req.method, path: req.path, user: req.header('X-User-Email') }); next(); });

app.get('/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok', service: 'ms-libros', db: 'up' }); }
  catch { res.status(503).json({ status: 'degraded', service: 'ms-libros', db: 'down' }); }
});

app.get('/libros', async (_req, res) => {
  const { rows } = await pool.query('SELECT * FROM libros ORDER BY id');
  res.json(rows);
});

app.get('/libros/:id', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM libros WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Libro no encontrado' });
  res.json(rows[0]);
});

app.post('/libros', async (req, res) => {
  const { titulo, autor } = req.body || {};
  if (!titulo || !autor) return res.status(400).json({ error: 'titulo y autor son obligatorios' });
  const { rows } = await pool.query(
    'INSERT INTO libros (titulo, autor, creado_por) VALUES ($1, $2, $3) RETURNING *',
    [titulo, autor, req.header('X-User-Id') || null]
  );
  res.status(201).json(rows[0]);
});

app.delete('/libros/:id', async (req, res) => {
  const r = await pool.query('DELETE FROM libros WHERE id = $1', [req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'Libro no encontrado' });
  res.status(204).end();
});

app.use((err, _req, res, _next) => { log('error', { error: err.message }); res.status(500).json({ error: 'Error interno' }); });

initDb().then(() => {
  const server = app.listen(PORT, () => log(`Escuchando en puerto ${PORT}`));
  // Factor IX - desechabilidad: apagado ordenado
  process.on('SIGTERM', () => { log('SIGTERM recibido, cerrando'); server.close(() => pool.end().then(() => process.exit(0))); });
}).catch((e) => { log('fatal', { error: e.message }); process.exit(1); });
