# 📚 Biblioteca Cloud Native — Microservicios con Docker, Firebase y 12 factores

Aplicación web con arquitectura de microservicios. Cada integrante desarrolla un componente, publica su imagen en Docker Hub y ejecuta la aplicación completa en Docker Desktop.

## Arquitectura

```
Usuario → Frontend (Nginx :8088) → API Gateway (:8080, valida token Firebase)
                                     ├── ms-libros    (:8001) → PostgreSQL
                                     ├── ms-prestamos (:8002) → MySQL   (consulta ms-libros)
                                     └── ms-resenas   (:8003) → MongoDB
```

| Componente | Responsable | Imagen Docker Hub | Tecnología | BD |
|---|---|---|---|---|
| ms-libros | Estudiante 1 | `usuario1/biblioteca-ms-libros:1.0` | Node.js + Express | PostgreSQL |
| ms-prestamos | Estudiante 2 | `usuario2/biblioteca-ms-prestamos:1.0` | Node.js + Express | MySQL |
| ms-resenas | Estudiante 3 | `usuario3/biblioteca-ms-resenas:1.0` | Node.js + Express | MongoDB |
| gateway + frontend | Estudiante 4 | `usuario4/biblioteca-gateway:1.0`, `usuario4/biblioteca-frontend:1.0` | Node.js / Nginx | — |

> ✏️ Reemplaza la tabla con los nombres reales de tu grupo y marca **tu** componente.

## Endpoints (a través del gateway, requieren `Authorization: Bearer <ID token>`)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/health` | Estado del gateway y de cada microservicio (público) |
| GET/POST | `/api/libros` | Listar / crear libros |
| GET/DELETE | `/api/libros/:id` | Ver / borrar libro |
| GET/POST | `/api/prestamos` | Mis préstamos / prestar un libro (valida en ms-libros) |
| PUT | `/api/prestamos/:id/devolver` | Devolver |
| GET/POST | `/api/resenas` | Listar / publicar reseña |

## Ejecutar

```bash
cp .env.example .env      # llenar imágenes, Firebase y contraseñas
docker compose pull       # descarga las imágenes de todos desde Docker Hub
docker compose up -d
docker compose ps
```

Abrir http://localhost:8088

## Prueba de tolerancia a fallos

```bash
docker compose stop ms-resenas      # libros y préstamos siguen funcionando
docker compose start ms-resenas     # se recupera solo
```

## 12 factores aplicados

| # | Factor | Cómo se aplica |
|---|---|---|
| I | Código base | Un repositorio Git, una imagen por microservicio |
| II | Dependencias | `package.json` + `package-lock.json`, `npm ci` en el Dockerfile |
| III | Configuración | Todo por variables de entorno (`.env`), sin secretos en el código ni en la imagen |
| IV | Servicios de soporte | BD y Firebase se conectan por URL/credenciales en variables; intercambiables |
| V | Build, release, run | `docker build` → `docker push` (tag 1.0) → `docker compose up` con config externa |
| VI | Procesos sin estado | Los servicios no guardan sesión; el estado vive en BD y la identidad en el token |
| VII | Asignación de puertos | Cada servicio expone su puerto vía `PORT` |
| VIII | Concurrencia | Se puede escalar: `docker compose up -d --scale ms-resenas=2` |
| IX | Desechabilidad | Arranque rápido, reintento de conexión a BD, apagado ordenado con `SIGTERM` |
| X | Paridad dev/prod | Mismas imágenes en cualquier máquina; solo cambia el `.env` |
| XI | Logs | JSON a stdout; se ven con `docker compose logs -f` |
| XII | Procesos de administración | Creación de tablas automática al iniciar; tareas puntuales con `docker compose exec` |

## Seguridad

- `.env` está en `.gitignore`. Solo se publica `.env.example` con valores de ejemplo.
- Los puertos de BD y microservicios no se publican al host: solo el gateway (8080) y el frontend (8088).
